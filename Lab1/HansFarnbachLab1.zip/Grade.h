#ifndef Lab_1_Grade_h
#define Lab_1_Grade_h

#include <string>
#include <vector>

using namespace std;

class Grade{
public:
    string course;
    string ID;
    string letter;
    double number;

    Grade(string gCourse, string gID, string gLetter, vector<string> gLet, vector<double> gNum){
        course = gCourse;
        ID = gID;
        letter = gLetter;
        for (int i = 0; i < gLet.size(); i++){
			if (letter == gLet[i]){
                number = gNum[i];
				break;
			}
        }
    }
    
    string getID(){
        return ID;
    }
    
    string getLetterGrade(){
        return letter;
    }
    
    double getNumberGrade(){
        return number;
    }
    
    bool operator < (Grade g) const{
        return (ID < g.ID) ||
        (ID == g.ID && course < g.course) ||
        (ID == g.ID && course == g.course && letter < g.letter);
    }
};

#endif
